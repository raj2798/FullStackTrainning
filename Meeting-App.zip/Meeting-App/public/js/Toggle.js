const hamBurger = document.querySelector("#ham-btn");
const listLeft = document.querySelector(".list-left");
hamBurger.addEventListener("click", show);

function show() {
  listLeft.style.left = 0;
  listLeft.style.display = "block";
}
const hamBurgerClose = document.querySelector("#cancel");

hamBurgerClose.addEventListener("click", hide);

function hide() {
  listLeft.style.left = "-100%";
  listLeft.style.display = "none";
}
